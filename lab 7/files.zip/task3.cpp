#include<iostream>
#include<string>
using namespace std;

class Currency {
public:
    double amount, exRate;
    string code, symbol;

    Currency(double a, string c, string s, double r) {
        amount = a; code = c; symbol = s; exRate = r;
    }
    virtual double convertToBase() { return amount * exRate; }
    virtual double convertTo(Currency& target) {
        return convertToBase() / target.exRate;
    }
    virtual void display() {
        cout << symbol << amount << " (" << code << ")" << endl;
    }
};

class Dollar : public Currency {
public:
    Dollar(double a) : Currency(a, "USD", "$", 1.0) {}
    double convertToBase() override { return amount; }
    void display() override {
        cout << "Dollar: $" << amount << " (USD) | Base: " << convertToBase() << endl;
    }
};

class Euro : public Currency {
public:
    Euro(double a) : Currency(a, "EUR", "€", 1.08) {}
    double convertToBase() override { return amount * exRate; }
    void display() override {
        cout << "Euro: €" << amount << " (EUR) | Base (USD): " << convertToBase() << endl;
    }
};

class Rupee : public Currency {
public:
    Rupee(double a) : Currency(a, "PKR", "Rs.", 0.0036) {}
    double convertToBase() override { return amount * exRate; }
    void display() override {
        cout << "Rupee: Rs." << amount << " (PKR) | Base (USD): " << convertToBase() << endl;
    }
};

int main() {
    Dollar d(100);
    Euro e(100);
    Rupee r(100);

    d.display();
    e.display();
    r.display();

    cout << endl;
    cout << "100 EUR to USD: " << e.convertToBase() << endl;
    cout << "100 PKR to USD: " << r.convertToBase() << endl;
    cout << "100 EUR to PKR: " << e.convertTo(r) << endl;

    return 0;
}
