#include<iostream>
#include<string>
using namespace std;

class Account {
public:
    int accNum;
    double bal;
    string name, type;

    Account(int n, double b, string nm, string t) {
        accNum = n; bal = b; name = nm; type = t;
    }
    void deposit(double amt) { bal += amt; }
    virtual void withdraw(double amt) {
        if (amt > bal) cout << "Insufficient funds" << endl;
        else bal -= amt;
    }
    virtual void calcInterest() { cout << "No interest for base account" << endl; }
    virtual void printStatement() {
        cout << "Account: " << accNum << " | Name: " << name << " | Balance: " << bal << endl;
    }
    void getInfo() {
        cout << "Type: " << type << " | Holder: " << name << " | Acc#: " << accNum << endl;
    }
};

class SavingsAccount : public Account {
public:
    double rate, minBal;
    SavingsAccount(int n, double b, string nm, double r, double mb)
        : Account(n, b, nm, "Savings") { rate = r; minBal = mb; }
    void withdraw(double amt) override {
        if (bal - amt < minBal) cout << "Cannot go below minimum balance" << endl;
        else bal -= amt;
    }
    void calcInterest() override {
        double interest = bal * rate / 100;
        cout << "Savings Interest: " << interest << endl;
        bal += interest;
    }
    void printStatement() override {
        Account::printStatement();
        cout << "Interest Rate: " << rate << "% | Min Balance: " << minBal << endl;
    }
};

class CheckingAccount : public Account {
public:
    double overdraft;
    CheckingAccount(int n, double b, string nm, double od)
        : Account(n, b, nm, "Checking") { overdraft = od; }
    void withdraw(double amt) override {
        if (amt > bal + overdraft) cout << "Overdraft limit exceeded" << endl;
        else bal -= amt;
    }
    void calcInterest() override { cout << "No interest for checking account" << endl; }
    void printStatement() override {
        Account::printStatement();
        cout << "Overdraft Limit: " << overdraft << endl;
    }
};

class FixedDepositAccount : public Account {
public:
    string matDate;
    double fixedRate;
    FixedDepositAccount(int n, double b, string nm, string md, double fr)
        : Account(n, b, nm, "Fixed Deposit") { matDate = md; fixedRate = fr; }
    void withdraw(double amt) override {
        cout << "Cannot withdraw before maturity date: " << matDate << endl;
    }
    void calcInterest() override {
        double interest = bal * fixedRate / 100;
        cout << "Fixed Deposit Interest: " << interest << endl;
        bal += interest;
    }
    void printStatement() override {
        Account::printStatement();
        cout << "Maturity Date: " << matDate << " | Fixed Rate: " << fixedRate << "%" << endl;
    }
};

int main() {
    SavingsAccount sa(1001, 5000, "Ahmed", 5.0, 1000);
    CheckingAccount ca(1002, 3000, "Sara", 500);
    FixedDepositAccount fa(1003, 10000, "Ali", "2026-12-31", 8.0);

    sa.deposit(2000);
    sa.withdraw(500);
    sa.calcInterest();
    sa.printStatement();
    cout << endl;

    ca.deposit(1000);
    ca.withdraw(4000);
    ca.printStatement();
    cout << endl;

    fa.withdraw(1000);
    fa.calcInterest();
    fa.printStatement();

    return 0;
}
