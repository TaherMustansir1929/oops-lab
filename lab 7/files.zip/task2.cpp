#include<iostream>
#include<string>
#define PI 3.14159
using namespace std;

class Shape {
public:
    int x, y;
    string color;
    int border;

    Shape(int px, int py, string c, int b) {
        x = px; y = py; color = c; border = b;
    }
    virtual void draw() {
        cout << "Drawing shape at (" << x << "," << y << ") color: " << color << endl;
    }
    virtual double calcArea() { return 0; }
    virtual double calcPerimeter() { return 0; }
};

class Circle : public Shape {
public:
    double r;
    Circle(int px, int py, string c, int b, double radius)
        : Shape(px, py, c, b) { r = radius; }
    void draw() override {
        cout << "Drawing Circle at (" << x << "," << y << ") radius: " << r << " color: " << color << endl;
    }
    double calcArea() override { return PI * r * r; }
    double calcPerimeter() override { return 2 * PI * r; }
};

class Rectangle : public Shape {
public:
    double w, h;
    Rectangle(int px, int py, string c, int b, double width, double height)
        : Shape(px, py, c, b) { w = width; h = height; }
    void draw() override {
        cout << "Drawing Rectangle at (" << x << "," << y << ") " << w << "x" << h << " color: " << color << endl;
    }
    double calcArea() override { return w * h; }
    double calcPerimeter() override { return 2 * (w + h); }
};

class Triangle : public Shape {
public:
    double a, b2, c;
    double base, ht;
    Triangle(int px, int py, string col, int brd, double sa, double sb, double sc, double bs, double hh)
        : Shape(px, py, col, brd) { a = sa; b2 = sb; c = sc; base = bs; ht = hh; }
    void draw() override {
        cout << "Drawing Triangle at (" << x << "," << y << ") color: " << color << endl;
    }
    double calcArea() override { return 0.5 * base * ht; }
    double calcPerimeter() override { return a + b2 + c; }
};

class Polygon : public Shape {
public:
    int sides;
    double sideLen;
    Polygon(int px, int py, string c, int b, int s, double sl)
        : Shape(px, py, c, b) { sides = s; sideLen = sl; }
    void draw() override {
        cout << "Drawing Polygon at (" << x << "," << y << ") sides: " << sides << " color: " << color << endl;
    }
    double calcArea() override {
        return (sides * sideLen * sideLen) / (4.0 * tan(PI / sides));
    }
    double calcPerimeter() override { return sides * sideLen; }
};

int main() {
    Circle ci(0, 0, "red", 1, 5.0);
    Rectangle re(1, 1, "blue", 2, 4.0, 6.0);
    Triangle tr(2, 2, "green", 1, 3, 4, 5, 3, 4);
    Polygon po(3, 3, "yellow", 1, 6, 3.0);

    ci.draw();
    cout << "Area: " << ci.calcArea() << " | Perimeter: " << ci.calcPerimeter() << endl << endl;

    re.draw();
    cout << "Area: " << re.calcArea() << " | Perimeter: " << re.calcPerimeter() << endl << endl;

    tr.draw();
    cout << "Area: " << tr.calcArea() << " | Perimeter: " << tr.calcPerimeter() << endl << endl;

    po.draw();
    cout << "Area: " << po.calcArea() << " | Perimeter: " << po.calcPerimeter() << endl;

    return 0;
}
