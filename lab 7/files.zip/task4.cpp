#include<iostream>
#include<string>
using namespace std;

class Person {
public:
    string name, addr, phone, email;
    int id;

    Person(string n, int i, string a, string p, string e) {
        name = n; id = i; addr = a; phone = p; email = e;
    }
    virtual void displayInfo() {
        cout << "Name: " << name << " | ID: " << id << " | Phone: " << phone << " | Email: " << email << endl;
    }
    void updateInfo(string n, string a, string p, string e) {
        name = n; addr = a; phone = p; email = e;
    }
};

class Student : public Person {
public:
    string courses;
    float gpa;
    int yr;

    Student(string n, int i, string a, string p, string e, string c, float g, int y)
        : Person(n, i, a, p, e) { courses = c; gpa = g; yr = y; }
    void displayInfo() override {
        Person::displayInfo();
        cout << "Courses: " << courses << " | GPA: " << gpa << " | Year: " << yr << endl;
    }
};

class Professor : public Person {
public:
    string dept, coursesTaught;
    double salary;

    Professor(string n, int i, string a, string p, string e, string d, string ct, double s)
        : Person(n, i, a, p, e) { dept = d; coursesTaught = ct; salary = s; }
    void displayInfo() override {
        Person::displayInfo();
        cout << "Dept: " << dept << " | Courses: " << coursesTaught << " | Salary: " << salary << endl;
    }
};

class Staff : public Person {
public:
    string dept, pos;
    double salary;

    Staff(string n, int i, string a, string p, string e, string d, string ps, double s)
        : Person(n, i, a, p, e) { dept = d; pos = ps; salary = s; }
    void displayInfo() override {
        Person::displayInfo();
        cout << "Dept: " << dept << " | Position: " << pos << " | Salary: " << salary << endl;
    }
};

class Course {
public:
    int cid, credits;
    string cname, instructor, schedule;

    Course(int id, string n, int cr, string ins, string sch) {
        cid = id; cname = n; credits = cr; instructor = ins; schedule = sch;
    }
    void registerStudent(Student& s) {
        cout << s.name << " registered in " << cname << endl;
    }
    void calcGrades() {
        cout << "Calculating grades for " << cname << endl;
    }
    void display() {
        cout << "Course: " << cname << " | Credits: " << credits << " | Instructor: " << instructor << " | Schedule: " << schedule << endl;
    }
};

int main() {
    Student st("Ali", 101, "Karachi", "0300-1234", "ali@uni.edu", "OOP, DS", 3.8, 2);
    Professor pr("Dr. Khan", 201, "Lahore", "0301-5678", "khan@uni.edu", "CS", "OOP, Algo", 120000);
    Staff sf("Bilal", 301, "Islamabad", "0302-9999", "bilal@uni.edu", "Admin", "Manager", 80000);
    Course co(401, "OOP", 3, "Dr. Khan", "Mon/Wed 10am");

    st.displayInfo();
    cout << endl;
    pr.displayInfo();
    cout << endl;
    sf.displayInfo();
    cout << endl;
    co.display();
    co.registerStudent(st);
    co.calcGrades();

    return 0;
}
