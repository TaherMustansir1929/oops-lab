#include<iostream>
#include<string>
using namespace std;

class Media {
public:
    string title, pubDate, uid, publisher;
    bool checkedOut;

    Media(string t, string pd, string id, string pub) {
        title = t; pubDate = pd; uid = id; publisher = pub; checkedOut = false;
    }
    virtual void displayInfo() {
        cout << "Title: " << title << " | ID: " << uid << " | Publisher: " << publisher << " | Date: " << pubDate << endl;
    }
    void checkOut() {
        if (checkedOut) cout << title << " is already checked out" << endl;
        else { checkedOut = true; cout << title << " checked out" << endl; }
    }
    void returnItem() {
        checkedOut = false;
        cout << title << " returned" << endl;
    }
};

class Book : public Media {
public:
    string author, isbn;
    int pages;

    Book(string t, string pd, string id, string pub, string a, string isn, int p)
        : Media(t, pd, id, pub) { author = a; isbn = isn; pages = p; }
    void displayInfo() override {
        Media::displayInfo();
        cout << "Author: " << author << " | ISBN: " << isbn << " | Pages: " << pages << endl;
    }
};

class DVD : public Media {
public:
    string director, rating;
    int duration;

    DVD(string t, string pd, string id, string pub, string d, int dur, string r)
        : Media(t, pd, id, pub) { director = d; duration = dur; rating = r; }
    void displayInfo() override {
        Media::displayInfo();
        cout << "Director: " << director << " | Duration: " << duration << " min | Rating: " << rating << endl;
    }
};

class CD : public Media {
public:
    string artist, genre;
    int tracks;

    CD(string t, string pd, string id, string pub, string a, int tr, string g)
        : Media(t, pd, id, pub) { artist = a; tracks = tr; genre = g; }
    void displayInfo() override {
        Media::displayInfo();
        cout << "Artist: " << artist << " | Tracks: " << tracks << " | Genre: " << genre << endl;
    }
};

class Magazine : public Media {
public:
    string issue;
    int vol;

    Magazine(string t, string pd, string id, string pub, string is, int v)
        : Media(t, pd, id, pub) { issue = is; vol = v; }
    void displayInfo() override {
        Media::displayInfo();
        cout << "Issue: " << issue << " | Volume: " << vol << endl;
    }
};

void search(Media* items[], int n, string title) {
    cout << "Search by title: " << title << endl;
    for (int i = 0; i < n; i++)
        if (items[i]->title == title) { items[i]->displayInfo(); return; }
    cout << "Not found" << endl;
}

void search(Media* items[], int n, int yr) {
    cout << "Search by year: " << yr << endl;
    for (int i = 0; i < n; i++)
        if (items[i]->pubDate.find(to_string(yr)) != string::npos) items[i]->displayInfo();
}

int main() {
    Book bk("Clean Code", "2008", "B001", "Prentice Hall", "Robert Martin", "978-0132350884", 431);
    DVD dv("Inception", "2010", "D001", "Warner Bros", "Christopher Nolan", 148, "PG-13");
    CD cd("Thriller", "1982", "C001", "Epic Records", "Michael Jackson", 9, "Pop");
    Magazine mg("Time", "2024-01", "M001", "Time Inc", "Jan 2024", 203);

    Media* items[] = { &bk, &dv, &cd, &mg };

    bk.displayInfo(); cout << endl;
    dv.displayInfo(); cout << endl;
    cd.displayInfo(); cout << endl;
    mg.displayInfo(); cout << endl;

    bk.checkOut();
    bk.checkOut();
    bk.returnItem();
    cout << endl;

    search(items, 4, string("Inception"));
    cout << endl;
    search(items, 4, 2008);

    return 0;
}
