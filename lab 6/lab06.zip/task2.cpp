#include<iostream>
#include<string>
using namespace std;

class Character {
public:
    int hp, dmg;
    Character(int h, int d) {
        hp = h;
        dmg = d;
    }
    void display() {
        cout << "HP: " << hp << endl;
        cout << "Damage: " << dmg << endl;
    }
};

class Enemy : public Character {
public:
    Enemy(int h, int d) : Character(h, d) {}
    void display() {
        cout << "[Enemy]" << endl;
        Character::display();
    }
};

class Player : public Character {
public:
    Player(int h, int d) : Character(h, d) {}
    void display() {
        cout << "[Player]" << endl;
        Character::display();
    }
};

class Wizard : public Player {
public:
    int mp;
    string spell;
    Wizard(int h, int d, int m, string s) : Player(h, d) {
        mp = m;
        spell = s;
    }
    void display() {
        cout << "[Wizard]" << endl;
        Character::display();
        cout << "Magic Power: " << mp << endl;
        cout << "Spell: " << spell << endl;
    }
};

int main() {
    Wizard w(100, 30, 80, "Fireball");
    w.display();
    return 0;
}
