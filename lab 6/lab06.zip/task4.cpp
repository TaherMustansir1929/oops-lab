#include<iostream>
#include<string>
using namespace std;

class Person {
public:
    string name;
    int age;
    Person(string n, int a) {
        name = n;
        age = a;
    }
    void display() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

class Student : virtual public Person {
public:
    int sid;
    int grade;
    Student(string n, int a, int id, int g) : Person(n, a) {
        sid = id;
        grade = g;
    }
    void display() {
        Person::display();
        cout << "Student ID: " << sid << endl;
        cout << "Grade: " << grade << endl;
    }
};

class Teacher : virtual public Person {
public:
    string subject;
    int room;
    Teacher(string n, int a, string s, int r) : Person(n, a) {
        subject = s;
        room = r;
    }
    void display() {
        Person::display();
        cout << "Subject: " << subject << endl;
        cout << "Room: " << room << endl;
    }
};

class GraduateStudent : public Student, public Teacher {
public:
    GraduateStudent(string n, int a, int id, int g, string s, int r)
        : Person(n, a), Student(n, a, id, g), Teacher(n, a, s, r) {}
    void display() {
        Person::display();
        cout << "Student ID: " << sid << endl;
        cout << "Grade: " << grade << endl;
        cout << "Subject: " << subject << endl;
        cout << "Room: " << room << endl;
    }
};

int main() {
    GraduateStudent gs("Ali", 25, 1001, 4, "Math", 302);
    gs.display();
    return 0;
}
