#include<iostream>
#include<string>
using namespace std;

class Device {
public:
    string brand, model;
    Device(string b, string m) : brand(b), model(m) {}
    void display() {
        cout << "Brand: " << brand << endl;
        cout << "Model: " << model << endl;
    }
};

class Smartphone : virtual public Device {
public:
    int simSlots;
    Smartphone(string b, string m, int s) : Device(b, m), simSlots(s) {}
    void display() {
        Device::display();
        cout << "SIM Slots: " << simSlots << endl;
    }
};

class Tablet : virtual public Device {
public:
    bool stylus;
    Tablet(string b, string m, bool st) : Device(b, m), stylus(st) {}
    void display() {
        Device::display();
        cout << "Stylus Support: " << (stylus ? "Yes" : "No") << endl;
    }
};

class HybridDevice : public Smartphone, public Tablet {
public:
    HybridDevice(string b, string m, int s, bool st) : Device(b, m), Smartphone(b, m, s), Tablet(b, m, st) {}
    void display() {
        Device::display();
        cout << "SIM Slots: " << simSlots << endl;
        cout << "Stylus Support: " << (stylus ? "Yes" : "No") << endl;
    }
};

int main() {
    HybridDevice hd("Samsung", "Galaxy Z", 2, true);
    hd.display();
    return 0;
}
