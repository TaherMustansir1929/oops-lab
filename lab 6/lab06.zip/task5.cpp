#include<iostream>
#include<string>
using namespace std;

class Vehicle {
public:
    string make, model;
    int year;
    Vehicle(string mk, string mo, int y) : make(mk), model(mo), year(y) {}
    void display() {
        cout << "Make: " << make << endl;
        cout << "Model: " << model << endl;
        cout << "Year: " << year << endl;
    }
};

class Car : public Vehicle {
public:
    int doors;
    float fuel;
    Car(string mk, string mo, int y, int d, float f) : Vehicle(mk, mo, y), doors(d), fuel(f) {}
    void display() {
        Vehicle::display();
        cout << "Doors: " << doors << endl;
        cout << "Fuel Efficiency: " << fuel << " mpg" << endl;
    }
};

class ElectricCar : public Car {
public:
    float battery;
    ElectricCar(string mk, string mo, int y, int d, float f, float b) : Car(mk, mo, y, d, f), battery(b) {}
    void display() {
        Car::display();
        cout << "Battery Life: " << battery << " kWh" << endl;
    }
};

int main() {
    ElectricCar ec("Tesla", "Model 3", 2023, 4, 0, 75.0);
    ec.display();
    return 0;
}
