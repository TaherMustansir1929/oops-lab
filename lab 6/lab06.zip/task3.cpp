#include<iostream>
using namespace std;

class Position {
public:
    int x, y, z;
    Position() { x = 0; y = 0; z = 0; }
    void setPos(int a, int b, int c) {
        x = a; y = b; z = c;
    }
    void showPos() {
        cout << "Position: (" << x << ", " << y << ", " << z << ")" << endl;
    }
};

class Health {
public:
    int hp;
    Health() { hp = 0; }
    void setHp(int h) { hp = h; }
    void showHp() {
        cout << "Health: " << hp << endl;
    }
};

class Character : public Position, public Health {
public:
    void display() {
        showPos();
        showHp();
    }
};

int main() {
    Character c;
    c.setPos(10, 20, 5);
    c.setHp(150);
    c.display();
    return 0;
}
